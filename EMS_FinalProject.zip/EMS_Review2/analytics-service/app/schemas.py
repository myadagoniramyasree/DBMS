"""Pydantic models — request/response validation for CO3."""
from pydantic import BaseModel, Field


class AttendanceTrendPoint(BaseModel):
    month: str
    total_present: int
    total_working: int
    attendance_pct: float


class AnalyticsSummary(BaseModel):
    total_employees: int
    pending_requests: int
    approved_requests: int
    rejected_requests: int
    avg_attendance_pct: float
    trend: list[AttendanceTrendPoint]


class SearchQuery(BaseModel):
    query: str = Field(..., min_length=2, max_length=300, description="Free-text search, e.g. 'medical emergency'")
    top_k: int = Field(5, ge=1, le=20)


class SearchResult(BaseModel):
    request_id: str
    emp_id: str
    type: str
    reason: str
    status: str
    score: float = Field(..., description="Cosine similarity score (0-1, higher = more relevant)")


class SearchResponse(BaseModel):
    query: str
    results: list[SearchResult]
