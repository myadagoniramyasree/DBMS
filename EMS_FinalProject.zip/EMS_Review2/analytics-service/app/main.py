"""
analytics-service — FastAPI microservice (CO3).
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import analytics, search

app = FastAPI(
    title="EMS Analytics Service",
    description="Analytics & semantic search microservice for the EMS Portal",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(analytics.router)
app.include_router(search.router)


@app.get("/api/health", tags=["health"])
async def health():
    return {"status": "analytics-service running"}
