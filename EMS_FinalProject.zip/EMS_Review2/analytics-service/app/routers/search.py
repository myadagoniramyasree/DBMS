from fastapi import APIRouter, Depends, Header
from ..auth import get_current_user, CurrentUser
from ..schemas import SearchQuery, SearchResponse, SearchResult
from ..vector_store import TfidfVectorStore
from .. import core_client

router = APIRouter(prefix="/api/search", tags=["semantic-search"])


@router.post("/requests", response_model=SearchResponse)
def search_requests(
    query: SearchQuery,
    authorization: str = Header(...),
    user: CurrentUser = Depends(get_current_user),
):
    token = authorization.replace("Bearer ", "")
    all_requests = core_client.fetch_requests(token)

    store = TfidfVectorStore()
    store.fit(all_requests, text_field="reason")
    matches = store.search(query.query, top_k=query.top_k)

    results = [
        SearchResult(
            request_id=doc["id"], emp_id=doc["empId"], type=doc["type"],
            reason=doc["reason"], status=doc["status"], score=round(score, 4),
        )
        for doc, score in matches
    ]
    return SearchResponse(query=query.query, results=results)
