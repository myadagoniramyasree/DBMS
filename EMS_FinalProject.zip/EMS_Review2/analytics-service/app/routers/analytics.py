from fastapi import APIRouter, Depends, Header
from ..auth import get_current_user, CurrentUser
from ..schemas import AnalyticsSummary, AttendanceTrendPoint
from .. import core_client

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/summary", response_model=AnalyticsSummary)
def get_summary(
    authorization: str = Header(...),
    user: CurrentUser = Depends(get_current_user),
):
    token = authorization.replace("Bearer ", "")
    employees = core_client.fetch_employees(token)
    attendance = core_client.fetch_attendance(token)
    requests_ = core_client.fetch_requests(token)

    pending = sum(1 for r in requests_ if r["status"] == "pending")
    approved = sum(1 for r in requests_ if r["status"] == "approved")
    rejected = sum(1 for r in requests_ if r["status"] == "rejected")

    by_month: dict[str, dict] = {}
    for a in attendance:
        m = a["month"]
        by_month.setdefault(m, {"present": 0, "working": 0})
        by_month[m]["present"] += a.get("presentDays", 0)
        by_month[m]["working"] += a.get("workingDays", 0)

    trend = [
        AttendanceTrendPoint(
            month=m,
            total_present=v["present"],
            total_working=v["working"],
            attendance_pct=round((v["present"] / v["working"]) * 100, 1) if v["working"] else 0.0,
        )
        for m, v in sorted(by_month.items())
    ]

    total_present = sum(a.get("presentDays", 0) for a in attendance)
    total_working = sum(a.get("workingDays", 0) for a in attendance)
    avg_pct = round((total_present / total_working) * 100, 1) if total_working else 0.0

    return AnalyticsSummary(
        total_employees=len(employees),
        pending_requests=pending,
        approved_requests=approved,
        rejected_requests=rejected,
        avg_attendance_pct=avg_pct,
        trend=trend,
    )
