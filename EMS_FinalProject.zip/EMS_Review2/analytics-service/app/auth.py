"""
JWT authentication dependency (CO3: JWT authentication via dependency injection).
Tokens are issued by core-service (Node/Express) on login; this service just
verifies them using the same shared secret, so a single login works across
every microservice.
"""
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

from .config import Settings, get_settings

bearer_scheme = HTTPBearer()


class CurrentUser:
    def __init__(self, id: str, role: str, name: str, email: str):
        self.id = id
        self.role = role
        self.name = name
        self.email = email


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    settings: Settings = Depends(get_settings),
) -> CurrentUser:
    token = credentials.credentials
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

    return CurrentUser(
        id=payload.get("id"), role=payload.get("role"),
        name=payload.get("name"), email=payload.get("email"),
    )


def require_admin(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
    if user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin access required")
    return user
