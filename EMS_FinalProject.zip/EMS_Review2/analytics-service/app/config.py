"""
Configuration for analytics-service, loaded from environment variables.
Injected as a FastAPI dependency (CO3: dependency injection).
"""
from functools import lru_cache
from pydantic import BaseModel
import os
from dotenv import load_dotenv

load_dotenv()


class Settings(BaseModel):
    jwt_secret: str = os.getenv("JWT_SECRET", "change_this_to_a_long_random_string")
    jwt_algorithm: str = "HS256"
    core_service_url: str = os.getenv("CORE_SERVICE_URL", "http://localhost:5000")
    port: int = int(os.getenv("PORT", "8000"))


@lru_cache
def get_settings() -> Settings:
    return Settings()
