"""
Vector store for semantic search over leave/request history (CO2).

This implements the vector-search *concept* required by the syllabus
("apply vector database concepts for semantic search using pgvector or
an equivalent vector store") using a lightweight, dependency-free TF-IDF
+ cosine-similarity index that needs no extra infrastructure to run or
demo.

--- Swapping to real pgvector in production -------------------------
1. `CREATE EXTENSION IF NOT EXISTS vector;` on a Postgres database.
2. `CREATE TABLE request_embeddings (
       request_id TEXT PRIMARY KEY,
       embedding VECTOR(384)
   );`
3. Replace `TfidfVectorStore.fit/search` below with calls that:
   - embed text using a model (e.g. sentence-transformers)
   - `INSERT ... ON CONFLICT DO UPDATE` the embedding
   - query with `ORDER BY embedding <-> :query_embedding LIMIT :k`
The rest of the API (SearchQuery -> SearchResponse) stays identical,
so routers/search.py would not need to change.
-----------------------------------------------------------------------
"""
from collections import Counter
import numpy as np


def _tokenize(text: str) -> list[str]:
    return [t for t in "".join(c.lower() if c.isalnum() else " " for c in text).split() if t]


class TfidfVectorStore:
    def __init__(self):
        self.vocab: dict[str, int] = {}
        self.idf: np.ndarray | None = None
        self.doc_vectors: np.ndarray | None = None
        self.docs: list[dict] = []

    def fit(self, docs: list[dict], text_field: str = "reason"):
        self.docs = docs
        tokenized = [_tokenize(d.get(text_field, "")) for d in docs]

        vocab_set = sorted({tok for toks in tokenized for tok in toks})
        self.vocab = {tok: i for i, tok in enumerate(vocab_set)}
        n_docs = len(docs)
        n_vocab = len(vocab_set)

        if n_docs == 0 or n_vocab == 0:
            self.doc_vectors = np.zeros((0, 0))
            self.idf = np.zeros(0)
            return

        df = np.zeros(n_vocab)
        tf_matrix = np.zeros((n_docs, n_vocab))
        for i, toks in enumerate(tokenized):
            counts = Counter(toks)
            total = max(len(toks), 1)
            for tok, c in counts.items():
                j = self.vocab[tok]
                tf_matrix[i, j] = c / total
                df[j] += 1

        self.idf = np.log((1 + n_docs) / (1 + df)) + 1
        self.doc_vectors = tf_matrix * self.idf

    def _vectorize_query(self, query: str) -> np.ndarray:
        toks = _tokenize(query)
        vec = np.zeros(len(self.vocab))
        counts = Counter(toks)
        total = max(len(toks), 1)
        for tok, c in counts.items():
            if tok in self.vocab:
                vec[self.vocab[tok]] = (c / total) * self.idf[self.vocab[tok]]
        return vec

    def search(self, query: str, top_k: int = 5) -> list[tuple[dict, float]]:
        if self.doc_vectors is None or self.doc_vectors.shape[0] == 0:
            return []
        q = self._vectorize_query(query)
        q_norm = np.linalg.norm(q)
        if q_norm == 0:
            return []

        doc_norms = np.linalg.norm(self.doc_vectors, axis=1)
        doc_norms[doc_norms == 0] = 1e-9
        sims = (self.doc_vectors @ q) / (doc_norms * q_norm)

        top_idx = np.argsort(-sims)[:top_k]
        return [(self.docs[i], float(sims[i])) for i in top_idx if sims[i] > 0]
