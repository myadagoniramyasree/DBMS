"""
Calls core-service's REST API to pull employee/attendance/request data.
This is the synchronous inter-service communication half of CO5
(the async half is the Kafka event core-service publishes on status change).
"""
import requests
from fastapi import HTTPException
from .config import get_settings


def _headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _get(path: str, token: str):
    settings = get_settings()
    try:
        r = requests.get(f"{settings.core_service_url}{path}", headers=_headers(token), timeout=5)
    except requests.exceptions.RequestException:
        raise HTTPException(status_code=502, detail=f"core-service unreachable at {settings.core_service_url}{path}")
    if not r.ok:
        raise HTTPException(status_code=502, detail=f"core-service returned {r.status_code} for {path}")
    return r.json()


def fetch_employees(token: str) -> list[dict]:
    return _get("/api/employees", token)


def fetch_attendance(token: str) -> list[dict]:
    return _get("/api/attendance", token)


def fetch_requests(token: str) -> list[dict]:
    return _get("/api/requests", token)
