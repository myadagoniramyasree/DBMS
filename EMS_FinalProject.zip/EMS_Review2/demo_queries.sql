-- ============================================================
-- EMS Portal — MySQL Demo Queries (Final Review)
-- Run these in MySQL Workbench or the mysql CLI while your
-- backend is running, to prove data is really persisted in
-- MySQL and not just in the browser.
-- ============================================================

USE ems_portal;

-- 1. Confirm all tables were created automatically by Sequelize
SHOW TABLES;

-- 2. View admin accounts
SELECT id, name, email, role, department, monthlySalary FROM users;

-- 3. View all employees added through the Employees page
SELECT id, name, email, designation, department, monthlySalary, joinDate
FROM employees
ORDER BY createdAt DESC;

-- 4. View attendance records marked through the Attendance page
SELECT empId, month, workingDays, presentDays,
       ROUND((presentDays / workingDays) * 100, 1) AS attendance_pct
FROM attendance
ORDER BY month DESC;

-- 5. View leave/permission requests submitted through the app
SELECT id, empId, type, fromDate, toDate, status, reason
FROM requests
ORDER BY createdAt DESC;

-- 6. Quick counts — good for a one-glance "proof of live data" moment
SELECT
  (SELECT COUNT(*) FROM employees) AS total_employees,
  (SELECT COUNT(*) FROM attendance) AS attendance_records,
  (SELECT COUNT(*) FROM requests WHERE status = 'pending')  AS pending_requests,
  (SELECT COUNT(*) FROM requests WHERE status = 'approved') AS approved_requests;

-- 7. LIVE DEMO: add an employee or leave request in the browser UI,
--    then re-run query #3 or #5 — the new row appears immediately.
