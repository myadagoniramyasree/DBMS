'use strict';
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { initDb } = require('./models');
const { connectMongo } = require('./config/mongo');
const { connectKafka } = require('./config/kafka');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/employees', require('./routes/employees'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/requests', require('./routes/requests'));
app.use('/api/audit', require('./routes/audit'));

app.get('/api/health', (req, res) => res.json({ status: 'core-service running' }));

const PORT = process.env.PORT || 5000;

Promise.resolve()
  .then(() => initDb())
  .then(() => connectMongo())
  .then(() => connectKafka())
  .then(() => {
    app.listen(PORT, () => console.log(`core-service listening on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
