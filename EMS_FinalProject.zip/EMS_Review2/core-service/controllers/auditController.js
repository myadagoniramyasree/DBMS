'use strict';
const { AuditLog, Notification } = require('../config/mongo');

exports.listAudit = async (req, res) => {
  try {
    const logs = await AuditLog.find().sort({ createdAt: -1 }).limit(100);
    res.json(logs);
  } catch {
    res.json([]);
  }
};

exports.listNotifications = async (req, res) => {
  try {
    const notes = await Notification.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(50);
    res.json(notes);
  } catch {
    res.json([]);
  }
};
