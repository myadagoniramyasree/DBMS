'use strict';
const bcrypt = require('bcryptjs');
const { Employee, Attendance } = require('../models');
const { logAudit } = require('../config/mongo');

const DESIG_PREFIX = { Technician: 'TCH', Executive: 'EXE', Intern: 'INT', Trainee: 'TRN', Manager: 'MGR', Incharge: 'INC' };

async function genCode(designation) {
  const pfx = DESIG_PREFIX[designation] || 'EMP';
  const count = await Employee.count({ where: { id: { [require('sequelize').Op.like]: `${pfx}%` } } });
  return pfx + String(count + 1).padStart(4, '0');
}

exports.list = async (req, res) => {
  const emps = await Employee.findAll({ attributes: { exclude: ['password'] }, order: [['createdAt', 'DESC']] });
  res.json(emps);
};

exports.create = async (req, res) => {
  try {
    const data = req.body;
    const id = await genCode(data.designation);
    const password = await bcrypt.hash(data.password || 'emp123', 10);
    const emp = await Employee.create({ ...data, id, password });
    const plain = emp.toJSON();
    delete plain.password;
    await logAudit('employee.created', req.user.id, req.user.role, id, { name: data.name });
    res.status(201).json(plain);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const { id } = req.params;
    const data = { ...req.body };
    if (data.password) data.password = await bcrypt.hash(data.password, 10);
    else delete data.password;
    await Employee.update(data, { where: { id } });
    const emp = await Employee.findByPk(id, { attributes: { exclude: ['password'] } });
    await logAudit('employee.updated', req.user.id, req.user.role, id, {});
    res.json(emp);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
};

exports.remove = async (req, res) => {
  const { id } = req.params;
  await Attendance.destroy({ where: { empId: id } });
  await Employee.destroy({ where: { id } });
  await logAudit('employee.deleted', req.user.id, req.user.role, id, {});
  res.json({ success: true });
};
