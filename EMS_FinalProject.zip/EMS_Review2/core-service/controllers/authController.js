'use strict';
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, Employee } = require('../models');

function signToken(u) {
  return jwt.sign(
    { id: u.id, role: u.role || 'employee', name: u.name, email: u.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );
}

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });

    let account = await User.findOne({ where: { email: email.toLowerCase() } });
    let role = account ? account.role : null;

    if (!account) {
      account = await Employee.findOne({ where: { email: email.toLowerCase() } });
      role = 'employee';
    }

    if (!account) return res.status(401).json({ error: 'Invalid email or password' });

    const match = await bcrypt.compare(password, account.password);
    if (!match) return res.status(401).json({ error: 'Invalid email or password' });

    const plain = account.toJSON();
    delete plain.password;
    plain.role = role;

    const token = signToken(plain);
    res.json({ token, user: plain });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error during login' });
  }
};

exports.me = async (req, res) => {
  try {
    const { id, role } = req.user;
    const Model = role === 'admin' ? User : Employee;
    const account = await Model.findByPk(id);
    if (!account) return res.status(404).json({ error: 'User not found' });
    const plain = account.toJSON();
    delete plain.password;
    plain.role = role;
    res.json(plain);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};
