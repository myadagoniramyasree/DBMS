'use strict';
const { Request } = require('../models');
const { logAudit, notify } = require('../config/mongo');
const { publishEvent } = require('../config/kafka');

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

exports.list = async (req, res) => {
  const { empId, status } = req.query;
  const where = {};
  if (empId) where.empId = empId;
  if (status) where.status = status;
  const records = await Request.findAll({ where, order: [['createdAt', 'DESC']] });
  res.json(records);
};

exports.create = async (req, res) => {
  try {
    const { empId, type, fromDate, toDate, reason } = req.body;
    if (!empId || !type || !fromDate || !reason) return res.status(400).json({ error: 'Missing required fields' });
    const record = await Request.create({
      id: uid(), empId, type, fromDate, toDate: toDate || fromDate, reason,
      status: 'pending', createdAt: Date.now(),
    });
    await logAudit('request.created', req.user.id, req.user.role, record.id, { type, empId });
    res.status(201).json(record);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
};

exports.updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    if (!['pending', 'approved', 'rejected'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    await Request.update({ status, updatedAt: Date.now() }, { where: { id } });
    const record = await Request.findByPk(id);
    await logAudit(`request.${status}`, req.user.id, req.user.role, id, { status });
    await notify(record.empId, `Your ${record.type} request was ${status}.`);
    await publishEvent('request.status.changed', { requestId: id, empId: record.empId, status, at: Date.now() });
    res.json(record);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
};

exports.remove = async (req, res) => {
  await Request.destroy({ where: { id: req.params.id } });
  await logAudit('request.deleted', req.user.id, req.user.role, req.params.id);
  res.json({ success: true });
};

exports.approveAll = async (req, res) => {
  await Request.update({ status: 'approved', updatedAt: Date.now() }, { where: { status: 'pending' } });
  await logAudit('request.approveAll', req.user.id, req.user.role, null);
  await publishEvent('request.status.changed', { bulk: true, status: 'approved', at: Date.now() });
  res.json({ success: true });
};
