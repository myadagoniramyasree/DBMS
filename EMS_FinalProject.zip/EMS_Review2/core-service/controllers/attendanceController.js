'use strict';
const { Attendance } = require('../models');

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

exports.list = async (req, res) => {
  const { empId, month } = req.query;
  const where = {};
  if (empId) where.empId = empId;
  if (month) where.month = month;
  const records = await Attendance.findAll({ where, order: [['month', 'DESC']] });
  res.json(records);
};

exports.upsert = async (req, res) => {
  try {
    const { empId, month, workingDays, presentDays } = req.body;
    if (!empId || !month) return res.status(400).json({ error: 'empId and month are required' });

    let record = await Attendance.findOne({ where: { empId, month } });
    if (record) {
      await record.update({ workingDays, presentDays });
    } else {
      record = await Attendance.create({ id: uid(), empId, month, workingDays, presentDays });
    }
    res.json(record);
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
};
