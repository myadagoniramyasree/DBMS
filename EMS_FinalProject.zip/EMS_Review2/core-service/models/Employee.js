'use strict';
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Employee = sequelize.define('Employee', {
  id: { type: DataTypes.STRING, primaryKey: true },
  name: { type: DataTypes.STRING, allowNull: false },
  email: { type: DataTypes.STRING, allowNull: false, unique: true },
  password: { type: DataTypes.STRING, allowNull: false },
  designation: DataTypes.STRING,
  department: DataTypes.STRING,
  phone: DataTypes.STRING,
  gender: DataTypes.STRING,
  location: DataTypes.STRING,
  dob: DataTypes.DATEONLY,
  joinDate: DataTypes.DATEONLY,
  monthlySalary: DataTypes.INTEGER,
  address: DataTypes.STRING,
  father: DataTypes.STRING,
  marital: DataTypes.STRING,
}, { tableName: 'employees', timestamps: true });

module.exports = Employee;
