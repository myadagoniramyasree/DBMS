'use strict';
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Attendance = sequelize.define('Attendance', {
  id: { type: DataTypes.STRING, primaryKey: true },
  empId: { type: DataTypes.STRING, allowNull: false },
  month: { type: DataTypes.STRING, allowNull: false },
  workingDays: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
  presentDays: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
}, {
  tableName: 'attendance', timestamps: true,
  indexes: [{ unique: true, fields: ['empId', 'month'] }],
});

module.exports = Attendance;
