'use strict';
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const User = sequelize.define('User', {
  id: { type: DataTypes.STRING, primaryKey: true },
  name: { type: DataTypes.STRING, allowNull: false },
  email: { type: DataTypes.STRING, allowNull: false, unique: true },
  password: { type: DataTypes.STRING, allowNull: false },
  role: { type: DataTypes.ENUM('admin', 'employee'), allowNull: false, defaultValue: 'employee' },
  designation: DataTypes.STRING,
  department: DataTypes.STRING,
  phone: DataTypes.STRING,
  gender: DataTypes.STRING,
  location: DataTypes.STRING,
  dob: DataTypes.DATEONLY,
  joinDate: DataTypes.DATEONLY,
  monthlySalary: DataTypes.INTEGER,
  address: DataTypes.STRING,
  father: DataTypes.STRING,
  marital: DataTypes.STRING,
}, { tableName: 'users', timestamps: true });

module.exports = User;
