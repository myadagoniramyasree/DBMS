'use strict';
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Request = sequelize.define('Request', {
  id: { type: DataTypes.STRING, primaryKey: true },
  empId: { type: DataTypes.STRING, allowNull: false },
  type: { type: DataTypes.STRING, allowNull: false },
  fromDate: DataTypes.DATEONLY,
  toDate: DataTypes.DATEONLY,
  reason: DataTypes.TEXT,
  status: { type: DataTypes.ENUM('pending', 'approved', 'rejected'), allowNull: false, defaultValue: 'pending' },
  createdAt: { type: DataTypes.BIGINT, allowNull: false },
  updatedAt: { type: DataTypes.BIGINT, allowNull: true },
}, { tableName: 'requests', timestamps: false });

module.exports = Request;
