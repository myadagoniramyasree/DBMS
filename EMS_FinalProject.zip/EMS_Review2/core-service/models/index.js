'use strict';
const sequelize = require('../config/db');
const User = require('./User');
const Employee = require('./Employee');
const Attendance = require('./Attendance');
const Request = require('./Request');
const bcrypt = require('bcryptjs');

async function seedDefaultUsers() {
  const count = await User.count();
  if (count > 0) return;

  const adminPwd = await bcrypt.hash('admin123', 10);
  const empPwd = await bcrypt.hash('emp123', 10);

  await User.bulkCreate([
    {
      id: 'ADMIN01', name: 'Admin User', email: 'admin@company.com', password: adminPwd,
      role: 'admin', designation: 'Manager', department: 'Management', phone: '9000000000',
      gender: 'Male', location: 'Hyderabad', dob: '1985-01-15', joinDate: '2020-01-01', monthlySalary: 80000,
    },
  ]);

  await Employee.bulkCreate([
    {
      id: 'EXE0001', name: 'Ravi Kumar', email: 'ravi@gmail.com', password: empPwd,
      designation: 'Executive', department: 'IT', phone: '9111111111',
      gender: 'Male', location: 'Nizampet', dob: '1995-03-22', joinDate: '2022-06-01', monthlySalary: 35000,
    },
  ]);

  console.log('[DB] Seeded default admin (admin@company.com / admin123) and employee (ravi@gmail.com / emp123)');
}

async function initDb() {
  await sequelize.authenticate();
  await sequelize.sync();
  await seedDefaultUsers();
}

module.exports = { sequelize, User, Employee, Attendance, Request, initDb };
