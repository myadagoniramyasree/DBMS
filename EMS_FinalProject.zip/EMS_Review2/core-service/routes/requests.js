'use strict';
const router = require('express').Router();
const ctrl = require('../controllers/requestController');
const { requireAuth, requireAdmin } = require('../middleware/auth');

router.get('/', requireAuth, ctrl.list);
router.post('/', requireAuth, ctrl.create);
router.patch('/:id/status', requireAuth, requireAdmin, ctrl.updateStatus);
router.patch('/approve-all', requireAuth, requireAdmin, ctrl.approveAll);
router.delete('/:id', requireAuth, ctrl.remove);

module.exports = router;
