'use strict';
const router = require('express').Router();
const ctrl = require('../controllers/auditController');
const { requireAuth, requireAdmin } = require('../middleware/auth');

router.get('/', requireAuth, requireAdmin, ctrl.listAudit);
router.get('/notifications', requireAuth, ctrl.listNotifications);

module.exports = router;
