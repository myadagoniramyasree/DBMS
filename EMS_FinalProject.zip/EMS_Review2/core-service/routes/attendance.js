'use strict';
const router = require('express').Router();
const ctrl = require('../controllers/attendanceController');
const { requireAuth, requireAdmin } = require('../middleware/auth');

router.get('/', requireAuth, ctrl.list);
router.post('/', requireAuth, requireAdmin, ctrl.upsert);

module.exports = router;
