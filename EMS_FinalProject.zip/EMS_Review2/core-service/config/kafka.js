'use strict';
const { Kafka } = require('kafkajs');

const KAFKA_BROKER = process.env.KAFKA_BROKER || 'localhost:9092';
const kafka = new Kafka({ clientId: 'core-service', brokers: [KAFKA_BROKER], retry: { retries: 0 }, connectionTimeout: 2000 });
const producer = kafka.producer();

let connected = false;

async function connectKafka() {
  try {
    await producer.connect();
    connected = true;
    console.log('[Kafka] Producer connected');
  } catch (err) {
    console.warn('[Kafka] Not available — events will not be published:', err.message);
  }
}

async function publishEvent(topic, payload) {
  if (!connected) return;
  try {
    await producer.send({ topic, messages: [{ value: JSON.stringify(payload) }] });
  } catch (err) {
    console.warn(`[Kafka] Failed to publish to ${topic}:`, err.message);
  }
}

module.exports = { connectKafka, publishEvent };
