'use strict';
const mongoose = require('mongoose');

const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/ems_audit';
let connected = false;

async function connectMongo() {
  try {
    await mongoose.connect(MONGO_URL, { serverSelectionTimeoutMS: 2000 });
    connected = true;
    console.log('[MongoDB] Connected for audit logs/notifications');
  } catch (err) {
    console.warn('[MongoDB] Not available — audit logging disabled:', err.message);
  }
}

const auditSchema = new mongoose.Schema({
  action: { type: String, required: true },
  actorId: String,
  actorRole: String,
  targetId: String,
  details: mongoose.Schema.Types.Mixed,
  createdAt: { type: Date, default: Date.now },
});
const AuditLog = mongoose.model('AuditLog', auditSchema);

const notificationSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  message: { type: String, required: true },
  read: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});
const Notification = mongoose.model('Notification', notificationSchema);

async function logAudit(action, actorId, actorRole, targetId, details = {}) {
  if (!connected) return;
  try {
    await AuditLog.create({ action, actorId, actorRole, targetId, details });
  } catch (err) {
    console.warn('[MongoDB] Failed to write audit log:', err.message);
  }
}

async function notify(userId, message) {
  if (!connected) return;
  try {
    await Notification.create({ userId, message });
  } catch (err) {
    console.warn('[MongoDB] Failed to write notification:', err.message);
  }
}

module.exports = { connectMongo, logAudit, notify, AuditLog, Notification };
