'use strict';
require('dotenv').config();
const { Sequelize } = require('sequelize');

const useSqlite = String(process.env.USE_SQLITE).toLowerCase() === 'true';

let sequelize;

if (useSqlite) {
  sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './ems_local.sqlite',
    logging: false,
  });
  console.log('[DB] Using SQLite (local/testing mode)');
} else {
  sequelize = new Sequelize(
    process.env.DB_NAME,
    process.env.DB_USER,
    process.env.DB_PASSWORD,
    {
      host: process.env.DB_HOST,
      port: process.env.DB_PORT || 3306,
      dialect: 'mysql',
      logging: false,
    }
  );
  console.log('[DB] Using MySQL');
}

module.exports = sequelize;
