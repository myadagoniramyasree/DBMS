package com.ems.payroll.controller;

import com.ems.payroll.config.JwtValidator;
import com.ems.payroll.dto.PayrollResponse;
import com.ems.payroll.service.PayrollService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payroll")
@CrossOrigin(origins = "*")
public class PayrollController {

    private final PayrollService payrollService;
    private final JwtValidator jwtValidator;

    public PayrollController(PayrollService payrollService, JwtValidator jwtValidator) {
        this.payrollService = payrollService;
        this.jwtValidator = jwtValidator;
    }

    @GetMapping("/{empId}/{month}")
    public ResponseEntity<?> getPayroll(
            @RequestHeader("Authorization") String authorization,
            @PathVariable String empId,
            @PathVariable String month) {
        try {
            jwtValidator.validate(authorization);
            PayrollResponse response = payrollService.calculate(authorization, empId, month);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/health")
    public ResponseEntity<?> health() {
        return ResponseEntity.ok(Map.of("status", "payroll-service running"));
    }
}
