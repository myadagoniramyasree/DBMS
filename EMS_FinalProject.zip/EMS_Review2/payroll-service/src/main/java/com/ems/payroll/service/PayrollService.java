package com.ems.payroll.service;

import com.ems.payroll.dto.AttendanceDto;
import com.ems.payroll.dto.EmployeeDto;
import com.ems.payroll.dto.PayrollResponse;
import org.springframework.stereotype.Service;

@Service
public class PayrollService {

    private final CoreServiceClient coreServiceClient;

    public PayrollService(CoreServiceClient coreServiceClient) {
        this.coreServiceClient = coreServiceClient;
    }

    public PayrollResponse calculate(String bearerToken, String empId, String month) {
        EmployeeDto emp = coreServiceClient.findEmployee(bearerToken, empId);
        if (emp == null) {
            throw new RuntimeException("Employee not found: " + empId);
        }

        AttendanceDto[] records = coreServiceClient.fetchAttendance(bearerToken, empId, month);
        AttendanceDto record = (records != null && records.length > 0) ? records[0] : null;

        int workingDays = record != null ? record.workingDays : 0;
        int presentDays = record != null ? record.presentDays : 0;
        int monthlySalary = emp.monthlySalary != null ? emp.monthlySalary : 0;

        int calculated = 0;
        if (workingDays > 0) {
            calculated = Math.round((float) monthlySalary / workingDays * presentDays);
        }

        return new PayrollResponse(emp.id, emp.name, month, monthlySalary, workingDays, presentDays, calculated);
    }
}
