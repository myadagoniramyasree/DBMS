package com.ems.payroll.dto;

public class PayrollResponse {
    public String empId;
    public String empName;
    public String month;
    public int monthlySalary;
    public int workingDays;
    public int presentDays;
    public int calculatedSalary;

    public PayrollResponse(String empId, String empName, String month, int monthlySalary,
                            int workingDays, int presentDays, int calculatedSalary) {
        this.empId = empId;
        this.empName = empName;
        this.month = month;
        this.monthlySalary = monthlySalary;
        this.workingDays = workingDays;
        this.presentDays = presentDays;
        this.calculatedSalary = calculatedSalary;
    }
}
