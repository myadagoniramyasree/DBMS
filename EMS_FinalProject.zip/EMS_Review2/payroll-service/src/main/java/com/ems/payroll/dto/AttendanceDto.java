package com.ems.payroll.dto;

public class AttendanceDto {
    public String id;
    public String empId;
    public String month;
    public Integer workingDays;
    public Integer presentDays;
}
