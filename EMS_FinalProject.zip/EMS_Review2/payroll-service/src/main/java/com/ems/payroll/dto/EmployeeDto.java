package com.ems.payroll.dto;

public class EmployeeDto {
    public String id;
    public String name;
    public String designation;
    public String department;
    public Integer monthlySalary;
}
