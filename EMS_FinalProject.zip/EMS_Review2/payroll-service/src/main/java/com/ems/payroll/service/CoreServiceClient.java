package com.ems.payroll.service;

import com.ems.payroll.dto.AttendanceDto;
import com.ems.payroll.dto.EmployeeDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Service
public class CoreServiceClient {

    @Value("${core.service.url}")
    private String coreServiceUrl;

    private final RestTemplate restTemplate;

    public CoreServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    private HttpHeaders authHeaders(String bearerToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", bearerToken);
        return headers;
    }

    public EmployeeDto[] fetchEmployees(String bearerToken) {
        HttpEntity<Void> entity = new HttpEntity<>(authHeaders(bearerToken));
        var response = restTemplate.exchange(
                coreServiceUrl + "/api/employees", HttpMethod.GET, entity, EmployeeDto[].class);
        return response.getBody();
    }

    public AttendanceDto[] fetchAttendance(String bearerToken, String empId, String month) {
        HttpEntity<Void> entity = new HttpEntity<>(authHeaders(bearerToken));
        String url = coreServiceUrl + "/api/attendance?empId=" + empId + "&month=" + month;
        var response = restTemplate.exchange(url, HttpMethod.GET, entity, AttendanceDto[].class);
        return response.getBody();
    }

    public EmployeeDto findEmployee(String bearerToken, String empId) {
        EmployeeDto[] all = fetchEmployees(bearerToken);
        if (all == null) return null;
        return Arrays.stream(all).filter(e -> e.id.equals(empId)).findFirst().orElse(null);
    }
}
