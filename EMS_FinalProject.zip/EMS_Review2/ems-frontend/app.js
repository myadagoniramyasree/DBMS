/* ============================================================
   app.js — EMS Shared Logic (LIVE BACKEND VERSION)
   Talks to the Node.js/Express + MySQL (Sequelize) API instead
   of localStorage. Same function names as before, so pages need
   minimal changes.
   ============================================================ */
'use strict';

const API_BASE = 'http://localhost:5000/api';

const Session = {
  get token() { return localStorage.getItem('ems_token'); },
  set token(t) { t ? localStorage.setItem('ems_token', t) : localStorage.removeItem('ems_token'); },
  get user() { try { return JSON.parse(localStorage.getItem('ems_currentUser')); } catch { return null; } },
  set user(u) { u ? localStorage.setItem('ems_currentUser', JSON.stringify(u)) : localStorage.removeItem('ems_currentUser'); },
  clear() { localStorage.removeItem('ems_token'); localStorage.removeItem('ems_currentUser'); }
};

async function api(path, method = 'GET', body) {
  const headers = { 'Content-Type': 'application/json' };
  if (Session.token) headers.Authorization = 'Bearer ' + Session.token;
  let res;
  try {
    res = await fetch(API_BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch (e) {
    toast('Cannot reach backend server. Is it running on :5000?', 'error');
    throw e;
  }
  if (res.status === 401) {
    Session.clear();
    if (!location.pathname.endsWith('index.html') && location.pathname !== '/') location.href = 'index.html';
    throw new Error('Unauthorized');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

const Cache = { employees: [], attendance: [], requests: [] };

async function refreshEmployees() { Cache.employees = await api('/employees'); }
async function refreshAttendance() { Cache.attendance = await api('/attendance'); }
async function refreshRequests() { Cache.requests = await api('/requests'); }

window.AppReady = (async function bootstrap() {
  if (!Session.user) return;
  await Promise.all([refreshEmployees(), refreshAttendance(), refreshRequests()]);
})();

const Auth = {
  current() { return Session.user; },
  async login(email, password) {
    try {
      const { token, user } = await api('/auth/login', 'POST', { email, password });
      Session.token = token;
      Session.user = user;
      return user;
    } catch {
      return null;
    }
  },
  logout() { Session.clear(); location.href = 'index.html'; },
  guard() { if (!this.current()) { location.href = 'index.html'; return false; } return true; },
  adminOnly() { if (!this.current() || this.current().role !== 'admin') { location.href = 'dashboard.html'; return false; } return true; }
};

const Emps = {
  all() { return Cache.employees; },
  find(id) { return Cache.employees.find(e => e.id === id); },
  genCode(des) {
    const map = { Technician: 'TCH', Executive: 'EXE', Intern: 'INT', Trainee: 'TRN', Manager: 'MGR', Incharge: 'INC' };
    const pfx = map[des] || 'EMP';
    const n = Cache.employees.filter(e => e.id.startsWith(pfx)).length + 1;
    return pfx + String(n).padStart(4, '0');
  },
  async add(e) { const created = await api('/employees', 'POST', e); await refreshEmployees(); return created; },
  async upd(id, d) { const updated = await api(`/employees/${id}`, 'PUT', d); await refreshEmployees(); return updated; },
  async del(id) { await api(`/employees/${id}`, 'DELETE'); await refreshEmployees(); await refreshAttendance(); }
};

const Users = {
  all() { return Cache.employees; },
  find(id) {
    return Cache.employees.find(e => e.id === id) || (Session.user && Session.user.id === id ? Session.user : null);
  },
  async upd(id, d) {
    if (Session.user && Session.user.id === id && Session.user.role === 'admin') {
      Session.user = { ...Session.user, ...d };
      return Session.user;
    }
    return Emps.upd(id, d);
  }
};

const Att = {
  all() { return Cache.attendance; },
  byEmp(id) { return Cache.attendance.filter(a => a.empId === id); },
  byMonth(m) { return Cache.attendance.filter(a => a.month === m); },
  find(empId, mo) { return Cache.attendance.find(a => a.empId === empId && a.month === mo); },
  async add(r) { const created = await api('/attendance', 'POST', r); await refreshAttendance(); return created; },
  async upd(id, d) {
    const rec = Cache.attendance.find(a => a.id === id);
    const created = await api('/attendance', 'POST', { empId: rec.empId, month: rec.month, ...d });
    await refreshAttendance();
    return created;
  },
  salary(emp, rec) {
    if (!rec || !rec.workingDays) return 0;
    return Math.round((emp.monthlySalary / rec.workingDays) * rec.presentDays);
  }
};

const Reqs = {
  all() { return Cache.requests; },
  byEmp(empId) { return Cache.requests.filter(r => r.empId === empId); },
  async add(r) { const created = await api('/requests', 'POST', r); await refreshRequests(); return created; },
  async upd(id, d) { const updated = await api(`/requests/${id}/status`, 'PATCH', d); await refreshRequests(); return updated; },
  async del(id) { await api(`/requests/${id}`, 'DELETE'); await refreshRequests(); },
  async approveAll() { await api('/requests/approve-all', 'PATCH'); await refreshRequests(); }
};

const DB = {
  clearAll() { toast('Bulk clear isn\u2019t wired to the live database in this build.', 'info'); }
};

function toast(msg, type = 'success', ms = 3400) {
  let c = document.getElementById('toasts');
  if (!c) { c = document.createElement('div'); c.id = 'toasts'; document.body.appendChild(c); }
  const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast t-${type}`;
  el.innerHTML = `<span style="font-size:17px">${icons[type] || icons.info}</span><span class="toast-msg">${msg}</span><span class="toast-x" onclick="this.parentElement.remove()">✕</span>`;
  c.appendChild(el);
  setTimeout(() => { el.style.animation = 'toastOut .3s ease forwards'; setTimeout(() => el.remove(), 300); }, ms);
}

function showModal(id) { const el = document.getElementById(id); if (el) { el.classList.add('show'); document.body.style.overflow = 'hidden'; } }
function hideModal(id) { const el = document.getElementById(id); if (el) { el.classList.remove('show'); document.body.style.overflow = ''; } }
document.addEventListener('click', e => {
  if (e.target.classList.contains('overlay')) { e.target.classList.remove('show'); document.body.style.overflow = ''; }
});

function confirm2(msg, onYes) {
  let ov = document.getElementById('confirm-ov');
  if (!ov) {
    document.body.insertAdjacentHTML('beforeend', `
      <div class="overlay" id="confirm-ov">
        <div class="modal modal-sm">
          <div class="modal-hd">
            <div class="modal-hd-icon">⚠️</div>
            <div class="modal-title">Confirm</div>
            <button class="modal-close" onclick="hideModal('confirm-ov')">✕</button>
          </div>
          <div class="modal-body"><p id="confirm-msg" style="font-size:14px;color:var(--text-3);line-height:1.7"></p></div>
          <div class="modal-ft">
            <button class="btn btn-secondary" onclick="hideModal('confirm-ov')">Cancel</button>
            <button class="btn btn-danger"    id="confirm-yes">Yes, Confirm</button>
          </div>
        </div>
      </div>`);
    ov = document.getElementById('confirm-ov');
  }
  document.getElementById('confirm-msg').textContent = msg;
  showModal('confirm-ov');
  const yBtn = document.getElementById('confirm-yes');
  yBtn.onclick = () => { hideModal('confirm-ov'); onYes(); };
}

function renderSidebar(active) {
  const u = Auth.current();
  if (!u) return;
  const pendCount = Reqs.all().filter(r => r.status === 'pending').length;

  const navItems = [
    { id: 'dashboard', icon: '📊', label: 'Dashboard', href: 'dashboard.html', show: true },
    { id: 'employees', icon: '👥', label: 'Employees', href: 'employees.html', show: true },
    { id: 'requests', icon: '📋', label: 'Requests', href: 'requests.html', show: true,
      badge: u.role === 'admin' ? pendCount : Reqs.byEmp(u.id).filter(r => r.status === 'pending').length },
    { id: 'approvals', icon: '✅', label: 'Approvals', href: 'approvals.html', show: u.role === 'admin',
      badge: u.role === 'admin' ? pendCount : 0 },
    { id: 'attendance', icon: '📅', label: 'Attendance', href: 'attendance.html', show: true },
    { id: 'leave', icon: '🏖️', label: 'Leave', href: 'leave.html', show: true },
    { id: 'profile', icon: '👤', label: 'My Profile', href: 'profile.html', show: true },
  ];

  const el = document.querySelector('.sidebar');
  if (!el) return;
  el.innerHTML = `
    <div class="sidebar-head">
      <div class="s-logo">E</div>
      <div class="s-brand">
        <div class="s-name">EMS Portal</div>
        <div class="s-sub">Employee Management</div>
      </div>
    </div>
    <div class="sidebar-body">
      <div class="nav-group-label">Main Menu</div>
      ${navItems.filter(item => item.show).map(item => `
        <a href="${item.href}" class="nav-item ${active === item.id ? 'active' : ''}">
          <div class="ni-icon">${item.icon}</div>
          <span>${item.label}</span>
          ${item.badge ? `<span class="nav-badge">${item.badge}</span>` : ''}
        </a>`).join('')}
    </div>
    <div class="sidebar-foot">
      <div class="s-user" onclick="location.href='profile.html'">
        <div class="s-avatar">${u.name.charAt(0)}</div>
        <div class="s-user-info">
          <div class="s-uname">${u.name}</div>
          <div class="s-urole">${u.role === 'admin' ? 'Administrator' : u.designation || 'Employee'}</div>
        </div>
      </div>
      <button class="s-logout" onclick="Auth.logout()">🚪 Sign Out</button>
    </div>`;
}

function renderTopbar(title) {
  const u = Auth.current();
  const el = document.querySelector('.topbar');
  if (!el || !u) return;
  el.innerHTML = `
    <div class="topbar-left">
      <div class="tb-page-title">${title}</div>
    </div>
    <div class="topbar-right">
      <button class="tb-icon-btn" onclick="location.href='requests.html'">🔔<span class="tb-notif-dot"></span></button>
      <button class="tb-icon-btn">⚙️</button>
      <div class="tb-user-chip" onclick="location.href='profile.html'">
        <div class="tb-chip-avatar">${u.name.charAt(0)}</div>
        <span class="tb-chip-name">${u.name}</span>
      </div>
    </div>`;
}

function validateLettersOnly(el) {
  el.value = el.value.replace(/[^a-zA-Z\s.'-]/g, '');
}

function validatePhone(el) {
  el.value = el.value.replace(/\D/g, '').slice(0, 10);
  const err = document.getElementById(el.id + '-err');
  const invalid = el.value.length > 0 && el.value.length !== 10;
  if (err) err.style.display = invalid ? 'block' : 'none';
  el.style.borderColor = invalid ? 'var(--red)' : '';
}

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
function allMonths() {
  const ms = new Set(Att.all().map(a => a.month));
  const d = new Date();
  for (let i = 0; i < 6; i++) { const clone = new Date(d); ms.add(clone.toLocaleString('default', { month: 'long' }) + ' ' + clone.getFullYear()); d.setMonth(d.getMonth() - 1); }
  return [...ms];
}
function nowMonth() {
  const d = new Date();
  return d.toLocaleString('default', { month: 'long' }) + ' ' + d.getFullYear();
}
function desigBadge(d) {
  const m = { Manager: 'b-blue', Executive: 'b-violet', Intern: 'b-amber', Trainee: 'b-navy', Technician: 'b-green', Incharge: 'b-red' };
  return m[d] || 'b-navy';
}
function statusBadge(s) {
  return { pending: 'b-amber', approved: 'b-green', rejected: 'b-red' }[s] || 'b-navy';
}
