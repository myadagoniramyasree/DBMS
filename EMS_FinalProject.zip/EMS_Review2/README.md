# EMS Portal — Full Project (Final Review)

A microservices-based Employee Attendance, Leave & Payroll Management System.

## What's inside

```
core-service/        Node.js + Express + MySQL (Sequelize) + MongoDB + Kafka + JWT
analytics-service/    FastAPI + Pydantic + JWT — analytics KPIs + semantic search
payroll-service/      Spring Boot + JWT — salary calculation via REST
ems-frontend/         HTML/CSS/JS frontend (talks to core-service)
docker-compose.yml    Runs everything together
demo_queries.sql      MySQL queries to prove live data during your demo
```

## Which CO each piece satisfies

| Piece | Technology | Covers |
|---|---|---|
| core-service | Node.js/Express, MySQL/Sequelize, JWT | CO4 |
| core-service | MongoDB audit logs alongside MySQL | CO2 |
| core-service | Kafka event publishing | CO5 |
| analytics-service | FastAPI, Pydantic, JWT, OpenAPI docs | CO3 |
| analytics-service | Semantic search (vector store) | CO2 |
| payroll-service | Spring Boot, REST client to core-service | CO4, CO5 |
| docker-compose.yml | All services containerized | CO6 |

---

## FASTEST PATH: Run with Docker (recommended for tomorrow)

If you have Docker Desktop installed, this is the quickest way to get
everything running at once:

```bash
cd EMS_Review2
docker compose up --build
```

Wait for all containers to start (first build takes a few minutes), then:
- Frontend: http://localhost:8080/index.html
- Core API: http://localhost:5000/api/health
- Analytics API docs: http://localhost:8000/docs
- Payroll API: http://localhost:8081/api/payroll/health

Login with:
- **Admin:** admin@company.com / admin123
- **Employee:** ravi@gmail.com / emp123

If Docker isn't installed or something fails to build, use the manual
steps below instead — they're more reliable under time pressure.

---

## MANUAL PATH (no Docker — run each service yourself)

### 1. core-service (REQUIRED — everything else depends on it)

```bash
cd core-service
npm install
cp .env.example .env
```

Edit `.env`:
- To test quickly without installing MySQL: leave `USE_SQLITE=true`
- For the real demo: set `USE_SQLITE=false` and fill in your MySQL
  credentials (`DB_USER`, `DB_PASSWORD`, `DB_NAME=ems_portal` — create
  this database first with `CREATE DATABASE ems_portal;`)
- Set `JWT_SECRET` to any random string — just use the SAME value in
  analytics-service and payroll-service's config too, since all three
  verify the same tokens.

Start it:
```bash
npm start
```
You should see `core-service listening on http://localhost:5000`.

MongoDB and Kafka are OPTIONAL — if they're not running, you'll see a
warning in the console but the app keeps working normally (just without
audit logs / events). Don't worry about installing them unless you want
to demo those specific features.

### 2. Frontend

```bash
cd ems-frontend
npx serve -p 8080
```
Open **http://localhost:8080/index.html** (not by double-clicking the
file — it must be served over http://).

### 3. analytics-service (optional — for CO2/CO3 demo)

```bash
cd analytics-service
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
cp .env.example .env   # make sure JWT_SECRET matches core-service's
./venv/bin/uvicorn app.main:app --port 8000
```
Open **http://localhost:8000/docs** to show the auto-generated OpenAPI
documentation (great for CO3).

### 4. payroll-service (optional — for CO4 demo)

Requires Java 17+ and Maven installed, with internet access (to download
Spring Boot dependencies — this will NOT work on a machine with no
internet):
```bash
cd payroll-service
mvn spring-boot:run
```
Runs on http://localhost:8081.

---

## Demo script for review

1. **Show the login + app working** — log in, add an employee, mark
   attendance, submit a leave request.
2. **Prove it's a real database** — open MySQL Workbench, run the
   queries in `demo_queries.sql`. Add something in the browser, re-run
   the query, show the new row appearing live.
3. **Show JWT** — open browser DevTools → Network tab → click any
   request → show the `Authorization: Bearer ...` header being sent.
4. **Show the analytics microservice** — open http://localhost:8000/docs,
   try the `/api/search/requests` endpoint with a query like "medical
   emergency" — show it finds relevant leave requests by meaning.
5. **Show the payroll microservice** (if running) — call
   `GET /api/payroll/{empId}/{month}` and show it computing salary by
   calling core-service over REST — a genuinely separate service.
6. **Mention Kafka/MongoDB** even if not running live: explain that
   core-service publishes events on request approval (Kafka) and logs
   every write action to MongoDB for audit purposes — show the code in
   `core-service/config/kafka.js` and `config/mongo.js` if asked.
7. **Mention Docker** — show `docker-compose.yml` and explain each
   service has its own Dockerfile and runs in its own container.

## If something breaks right before your review

- **Frontend shows no styling / nothing loads:** you opened the HTML
  file directly. Serve it with `npx serve -p 8080` and use the
  `http://localhost:8080/...` URL instead.
- **Login fails:** make sure core-service is actually running
  (`http://localhost:5000/api/health` should respond) and that
  `ems-frontend/app.js`'s `API_BASE` matches where core-service is
  running.
- **"Cannot reach backend server" toast:** core-service isn't running,
  or you're on the wrong port.
- **MySQL connection refused:** double check `.env` credentials, and
  that you ran `CREATE DATABASE ems_portal;` first.
- When in doubt, fall back to `USE_SQLITE=true` in core-service's
  `.env` — the whole demo still works, just without needing MySQL
  installed. It's not as strong a demo but keeps you from going in
  with nothing working.
